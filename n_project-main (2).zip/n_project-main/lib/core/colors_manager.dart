import 'package:flutter/material.dart';

class ColorsManager{
  static const Color kPrimaryColor=Color(0xffa6a6a6);
}