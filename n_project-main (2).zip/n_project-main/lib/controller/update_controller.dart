import 'package:flutter/material.dart';

class UpdateController{
  TextEditingController firstNameController=TextEditingController();
  TextEditingController emailController=TextEditingController();
  TextEditingController passwordController=TextEditingController();
  TextEditingController nationalController=TextEditingController();
  TextEditingController phoneNumberController=TextEditingController();
  TextEditingController addressController=TextEditingController();
}